﻿using Entities.Concrete;
using Microsoft.EntityFrameworkCore;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DataAccess.Concrete.EntityFramework
{
    public class CoffeeShopContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=CoffeeShop;Trusted_Connection=True;MultipleActiveResultSets=true");
        }

        public virtual DbSet<CoffeeShop> CoffeeShop { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        
    }
}
